import sppq

sppq.printt(text=sppq.percent(100, 100))