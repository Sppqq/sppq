from sppq import *

printt(text=str(percent(46, 500)))

print(bigtext('HELLO'))

pbar = pbar(500)
