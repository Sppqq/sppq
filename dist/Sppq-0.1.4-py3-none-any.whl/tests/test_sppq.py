import sppq

sppq.printt('Привееееет')
print(sppq.retell('https://backrooms.fandom.com/wiki/Level_0'))
print(sppq.cl())
print(sppq.ask_gpt('Привет!'))