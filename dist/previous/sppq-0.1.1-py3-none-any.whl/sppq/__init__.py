import sppq

def printt(text: str, speed: float = .02, newLine=True):
    sppq.printt(text, speed, newLine)