from sppq import *

print(bigtext('HELLO'))

printt(send_webhook(webhook_url='https://discord.com/api/webhooks/1136007842969702421/VLVRtO3xne0Euc92_Hf5D7Z4qvXzLU859q6_-uobDcKx2WOq1urETHgzIZqkj8Yy5E1b',
                    content = 'Привеь'))