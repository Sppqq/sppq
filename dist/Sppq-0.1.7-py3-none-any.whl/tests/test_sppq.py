import sppq

sppq.printt('Привееееет')