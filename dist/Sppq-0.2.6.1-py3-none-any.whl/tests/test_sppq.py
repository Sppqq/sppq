from sppq import *

printt(send_webhook(webhook_url='https://discord.com/api/webhooks/1206271216164282368/a809-Pkw6HyHhFvBq0Q0iC6y2DwsLRpMIREOJ_rMqymCbAUHR0kDJXDd9DYkNoNj9cOu',
                    content = 'Привет', username='❖Sergey❖', avatar_url='http://tinyurl.com/2y7fcvlp'))