from sppq import *

printt('Hello world')